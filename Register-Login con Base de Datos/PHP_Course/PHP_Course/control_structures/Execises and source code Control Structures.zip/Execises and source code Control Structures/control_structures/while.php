<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php
//While loop - Don't know the number of iterations
//Do-while loop
//For loop
//Foreach loop

$x = 1;

while ($x <= 10) {
    echo $x . "<br>";
    $x++;
}

?>
</body>
</html>
