<html>
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php
//While loop
//Do-while loop First do, then while
//For loop
//Foreach loop

$cookie = 1;

do {
    echo "I love cookies! <br>";
    $cookie ++;
} while ($cookie < 0);

echo "<br>";
/*
while ($cookie < 1) {
    echo "I love cookies! <br>";
    $cookie ++;
}
*/
?>
</body>
</html>
